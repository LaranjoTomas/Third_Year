function [Bloom] = BloomInit(n)
    Bloom = zeros(1,n);
end