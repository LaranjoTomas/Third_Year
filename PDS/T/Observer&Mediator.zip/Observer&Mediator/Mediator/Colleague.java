package Mediator;

public interface Colleague {
    void sendMessage();
    void receiveMessage(String message);
}
