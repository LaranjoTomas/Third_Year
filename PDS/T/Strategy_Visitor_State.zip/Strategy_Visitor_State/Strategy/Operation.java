package Strategy;

public interface Operation {
    public int performOperation(int num1, int num2);
}
