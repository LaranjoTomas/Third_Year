package State;

public interface State {
    public void pull(CeilingFan fan);

    public String getState();
}
